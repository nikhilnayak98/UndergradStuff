#include<fcntl.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdio.h>
#include<sys/stat.h>
#include<semaphore.h>
int main()
{  
  sem_t *sem;
  int val;pid_t pid;
  char *name="/cse";
  sem=sem_open(name,O_CREAT,0620,1);
  pid=fork();
  if(pid==0){
       sem_wait(sem);
       fprintf(stderr," I  am a child\n");
   }
  else{

        sem_wait(sem);
	fprintf(stderr," I  am parent\n");
         wait(NULL);
        printf("After wait\n");
       
   }
   return 0;
}
  
  
