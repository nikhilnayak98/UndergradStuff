#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
long var=100;
void *write1(void *arg);
void *write2(void *arg);
void *read1(void *arg);
void *read2(void *arg);

pthread_rwlock_t rwlock=PTHREAD_RWLOCK_INITIALIZER;
int main()
{
 pthread_t w1,w2, r1 , r2;
 printf("Parent Thread starts\n"); 
//pthread_rwlock_init(&rwlock,NULL);
 pthread_create(&r1,NULL,read1,NULL);
pthread_create(&r2,NULL,read2,NULL);
 pthread_create(&w1,NULL,write1,NULL);
 pthread_create(&w2,NULL,write2,NULL);

 pthread_join(w1,NULL);
 pthread_join(w2,NULL);
 pthread_join(r1,NULL);
pthread_join(r2,NULL);
pthread_rwlock_destroy(&rwlock);
 printf("Final value of var=%ld\n",var);
 printf("Parent Thread Ends\n"); 
}
void *write1(void *arg)
{
 
  long i;
  int ret;
ret=pthread_rwlock_wrlock(&rwlock);
 printf("write 1 acquires lock\n");
  for(i=0;i<1000000;i++){
  
     var=var+1;
  
  }
 pthread_rwlock_unlock(&rwlock);
 printf("write 1 releases lock\n");
  pthread_exit(NULL);//return NULL;
}
void *write2(void *arg)
{

  long i;
  int ret;
 ret=pthread_rwlock_wrlock(&rwlock);
printf("write 2 acquires lock\n");

  for(i=0;i<1000000;i++){
  
     var=var-1;
  
  }
 pthread_rwlock_unlock(&rwlock);
 printf("write 2 releases lock\n");
  pthread_exit(NULL);//return NULL;
}

void *read1(void *arg)
{
  long i;
  int ret;
 
pthread_rwlock_rdlock(&rwlock);
 printf("read 1 acquires lock\n");
  for(i=0;i<10;i++){
     printf("read 1 value of var=%ld\n",var);
sleep(1);
   
  }
pthread_rwlock_unlock(&rwlock);
 printf("read 1 releases lock\n");
  pthread_exit(NULL);//return NULL;
}

void *read2(void *arg)
{
  long i;
  int ret;
pthread_rwlock_rdlock(&rwlock);
 printf("read 2 acquires lock\n");
  for(i=0;i<10;i++){

     printf("read2 value of var=%ld\n",var);
sleep(1);

  }
   pthread_rwlock_unlock(&rwlock);
  printf("read 2 releases lock\n");
  pthread_exit(NULL);//return NULL;
}
