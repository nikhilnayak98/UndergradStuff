#include<pthread.h>
#include<stdio.h>
#include<unistd.h>

void *myfun(void *arg);

int main()
    {
pid_t pid;     
//     int id;
     char mesg[]="thread1";
     char mesg1[]="thread2";
if((pid=fork())==0)
{
myfun((void *)mesg1);
}
else
{
myfun((void *)mesg1);
}
    // pthread_t tid1,tid2;
   //  pthread_create(&tid1, NULL, myfun, (void *)mesg);
    // perror("err::");
    // pthread_create(&tid2, NULL, myfun, (void *)mesg1); 
    // perror("err::");
    // printf("running in main\n");
     //pthread_join(tid1, NULL);
     // pthread_join(tid2, NULL);
//myfun((void *)mesg);
//myfun((void *)mesg1);

     return 0;
    }

void *myfun(void *arg)
    {
     int i;
     for(i=0;i<20;i++)
     {     
     printf("%d\n", i);
     sleep(1);
     }     

    }      





