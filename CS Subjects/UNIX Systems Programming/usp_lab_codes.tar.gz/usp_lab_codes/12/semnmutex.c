#include<stdio.h>
#include<unistd.h>
#include<semaphore.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<pthread.h>
long var=10;
void *f2(void *arg);
void *f1(void *arg);
sem_t *sem;
int main()
{
 pthread_t t1,t2;
 sem=sem_open("/iter",O_CREAT,0662,1);
 printf("Parent Thread starts\n"); 
 pthread_create(&t1,NULL,f1,NULL);
 pthread_create(&t2,NULL,f2,NULL);
 pthread_join(t1,NULL);
 pthread_join(t2,NULL);
 printf("Final value of var=%ld\n",var);
 printf("Parent Thread Ends\n"); 
 sem_close(sem);
 sem_unlink("/iter");
}
void *f1(void *arg)
{
  long i;
  for(i=0;i<10000000;i++){
     sem_wait(sem);
     var=var+1;
     sem_post(sem);
  }
  pthread_exit(NULL);//return NULL;
}
void *f2(void *arg)
{
  long i;
  for(i=0;i<10000000;i++){
     sem_wait(sem);
     var=var-1;
     sem_post(sem);
  }
  pthread_exit(NULL);//return NULL;
}
